
<?php 
$n=0;

$arr = explode('=',$_GET['cname']);



$page = $arr[1] != '' ? $arr[1] : 1;
$limit = 9;
$offset = ($page - 1) * $limit;
$sql = ' Limit ' . $offset . ',' . $limit;
?>
<div class="middle">

	<div class="container">

		<div class="page_title_wrapper">

			<h1 class="page_title"><?php echo $sign['product'][$lng] ?></h1>


		</div>

		<div class="middle_content clearfix">

			<div class="left_sidebar">

				<div class="block_products_sidebar">

					<div class="block_content">

					<?php

					$lng1sor=$db->prepare('SELECT * FROM kateqoriyalar where s_id="0" and l_id=:lid  order by ordering asc  ');

              		$lng1sor->execute(array('lid'=>$lng1)); 

					$lng1count=$lng1sor->rowCount();

					$record=0;

              		while ($lng1cek=$lng1sor->fetch(PDO::FETCH_ASSOC)) 

                  	{ 

                  	$record++; 

					?>

						<div class="col col_<?php echo $record;  if($_GET['cat']!='' and $_GET['cat']==$lng1cek['kat_id']){ echo ' active'; } ?>">

							<div class="image"><a href="<?php echo $site_url.$lng.'/shop/'.$lng1cek['kat_id'].'/'; ?>"><img src="<?php echo $site_url; ?>cms/images/<?php echo  $lng1cek['picture']; ?>" alt="<?php echo  $lng1cek['name']; ?>"></a></div>

							<div class="title"><div  class="field_content" ><a href="<?php echo $site_url.$lng.'/shop/'.$lng1cek['kat_id'].'/'; ?>"><?php echo  $lng1cek['name']; ?></a></div></div>

						</div>

					<?php

					}  

					?>

					</div>

				</div>

			</div>	

			<div class="page_content">

				<div class="block_goods good_page">

					<div class="good_header clearfix">

						<div class="label"><?php echo $home_body['sort'][$lng]; ?></div>

						<div class="links_wrap">
						    <?php 
						        if(strlen($_GET['cat'])>1){
						            $cat = explode('-',$_GET['cat']);
						            $active_sort = $cat[1];
						            $value = $cat[0];
						        }else{
						            $active_sort = 0;
						            $value =$_GET['cat'];
						        }
						        
						    ?>
                            <a href="<?php echo $site_url.$lng.'/shop/'.$value.'-0/'; ?>" class="link <?php if($active_sort == 0) echo 'active'; ?>">
							    <?php echo $home_body['price'][$lng]; ?><span></span>
							</a>

							<a href="<?php echo $site_url.$lng.'/shop/'.$value.'-1/'; ?>" class="link <?php if($active_sort == 1) echo 'active'; ?>">
							    <?php echo $home_body['popularity'][$lng]; ?>
							</a>

							<a href="<?php echo $site_url.$lng.'/shop/'.$value.'-2/'; ?>" class="link <?php if($active_sort == 2) echo 'active'; ?>">
							    <?php echo $home_body['novelty'][$lng]; ?>
							</a>

						</div>

					</div>





					<div class="good_content">





<?php

					if ($_GET['cat']!='') 

					{	

						// $lng01sor=$db->prepare('SELECT * FROM mehsul_kateqoriya where s_id="1" and l_id=:lid  order by ordering asc  ');

						// $lng01sor->execute(array('lid'=>$lng1)); 

						// while ($lng01cek=$lng01sor->fetch(PDO::FETCH_ASSOC)) 

						// {  

						// }



                        if($active_sort == 0){
                            $lng01sor=$db->prepare('SELECT * FROM mehsul m , mehsul_kateqoriya  mk where m.s_id="1" and mk.kat_u_id=:ds and m.u_id=mk.m_u_id and m.l_id=:lid  order by m.price_1 asc'.$sql);
                        }else if($active_sort == 1){
                            $lng01sor=$db->prepare('SELECT * FROM mehsul m , mehsul_kateqoriya  mk where m.s_id="1" and mk.kat_u_id=:ds and m.u_id=mk.m_u_id and m.l_id=:lid  order by m.ordering asc'.$sql);
                        }else if($active_sort == 2){
                            $lng01sor=$db->prepare('SELECT * FROM mehsul m , mehsul_kateqoriya  mk where m.s_id="1" and mk.kat_u_id=:ds and m.u_id=mk.m_u_id and m.l_id=:lid  order by m.date desc'.$sql);
                        } 
              			$lng01sor->execute(array('lid'=>$lng1 , 'ds'=>s($_GET['cat']))); 

					}

					else

					{
                        
                        if($active_sort == 0){
                            $lng01sor=$db->prepare('SELECT * FROM mehsul where s_id="1" and l_id=:lid ORDER BY price_1 desc'.$sql);
                        }else if($active_sort == 1){
                            $lng01sor=$db->prepare('SELECT * FROM mehsul where s_id="1" and l_id=:lid order by ordering asc'.$sql);
                        }else if($active_sort == 2){
                            
                            $lng01sor=$db->prepare('SELECT * FROM mehsul where s_id="1" and l_id=:lid order by date desc'.$sql);
                        } 
                        
						    $lng01sor->execute(array('lid'=>$lng1));
                        
              			 

					}

					

					$lng01count=$lng01sor->rowCount();

					$decods=0;

              		while ($lng01cek=$lng01sor->fetch(PDO::FETCH_ASSOC)) 

                  	{  

              		$decods++;

					?>

						<div class="col col_<?php  echo $decods; ?> smcs">
						    <a href="<?php echo $site_url.$lng.'/shop/4/'.$lng01cek['u_id'].'/' ?>" class="image">

								<div class="field_content"><img class='otk' src="<?php echo $site_url.'cms/images/'.$lng01cek['image_url']; ?>" alt="<?php  echo $lng01cek['name']; ?>"></div>

							</a>

							<div class="title"><a href="<?php echo $site_url.$lng.'/shop/4/'.$lng01cek['u_id'].'/' ?>"><?php  echo $lng01cek['name']; ?>	</a></div>

							<div class="price_wrap">

								<div class="old_price" style="text-decoration: none;"><?php  if($lng01cek['home']==1){ echo $lng01cek['shipping_1'].' USD'; }  ?></div>

								<div class="price"><?php  if($lng01cek['home']==1){ echo $lng01cek['price_1'].' USD'; }  ?><span></span></div>

							</div>

							<div class="add_to_basket">

							<?php

							if (!is_null($lng01cek['home']))

							{

							?>	

								<input type="button" value='<?php echo $home_body['buy'][$lng]; ?>'  data-text="Add To Cart"  class="addtocart add_to_basket" onclick="ekle(<?php echo $lng01cek['u_id'];  ?>)"  id="<?php echo $lng01cek['u_id'] ;  ?>" data-name="<?php echo $lng01cek['name'] ;  ?>"  data-ship="<?php echo $lng01cek['shipping_1'] ;  ?>" data-price="<?php echo $lng01cek['price_1'] ;  ?>" data-img="<?php echo $lng01cek['image_url'] ;  ?>"  >

								<!-- <a href="<?php echo $site_url.$lng.'/shop/4/'.$lng01cek['u_id'].'/' ?>">Купить</a> -->

							<?php 

							} 

							?>	

							</div>

						</div>
				
<!-- 					<div class="col col_4">

						<div class="image">

							<div class="field_content"><img src="<?php echo $site_url; ?>images/good_2.png" alt="Товар"></div>

						</div>

						<div class="title"><a href="#">Masculine & Feminine Elegance LN7002/LN7004</a></div>

						<div class="price_wrap">

							<div class="old_price">2 699</div>

							<div class="price">1 999<span>руб</span></div>

						</div>

						<div class="add_to_basket"><a href="#">Купить</a></div>

					</div> -->

<!-- 					<div class="col col_4">

						<div class="image">

							<div class="field_content"><img src="<?php echo $site_url; ?>images/good_3.png" alt="Товар"></div>

						</div>

						<div class="title"><a href="#">Bottega Veneta Eau Legere EDT Eau De Toilette Spray 30ml/1oz Perfume</a></div>

						<div class="price_wrap">

							<div class="old_price">2 699</div>

							<div class="price">1 999<span>руб</span></div>

						</div>

						<div class="add_to_basket"><a href="#">Купить</a></div>

					</div> -->

<!-- 					<div class="col col_4">

						<div class="image">

							<div class="field_content"><img src="<?php echo $site_url; ?>images/good_4.png" alt="Товар"></div>

						</div>

						<div class="title"><a href="#">Masculine & Feminine Elegance LN7002/LN7004</a></div>

						<div class="price_wrap">

							<div class="old_price">2 699</div>

							<div class="price">1 999<span>руб</span></div>

						</div>

						<div class="add_to_basket"><a href="#">Купить</a></div>

					</div> -->

<!-- 					<div class="col col_4">

						<div class="image">

							<div class="field_content"><img src="<?php echo $site_url; ?>images/good_2.png" alt="Товар"></div>

						</div>

						<div class="title"><a href="#">Bottega Veneta Eau Legere EDT Eau De Toilette Spray 30ml/1oz Perfume</a></div>

						<div class="price_wrap">

							<div class="old_price">2 699</div>

							<div class="price">1 999<span>руб</span></div>

						</div>

						<div class="add_to_basket"><a href="#">Купить</a></div>

					</div> -->

					<?php

						if ($decods%3==0) 

						{

						?>

							<div class="line">Разделяющая черта</div>

						<?php 

						}

					}  

					?>

<?php if ($_GET['cat']!=''){ ?>		
						<!--paginator-->
						<?php
					if($active_sort == 0){
                        $contractquer=$db->prepare('SELECT * FROM mehsul m , mehsul_kateqoriya  mk where m.s_id="1" and mk.kat_u_id=:ds and m.u_id=mk.m_u_id and m.l_id=:lid  order by m.price_1 asc');
                    }else if($active_sort == 1){
                        $contractquer=$db->prepare('SELECT * FROM mehsul m , mehsul_kateqoriya  mk where m.s_id="1" and mk.kat_u_id=:ds and m.u_id=mk.m_u_id and m.l_id=:lid  order by m.ordering asc');
                    }else if($active_sort == 2){
                        $contractquer=$db->prepare('SELECT * FROM mehsul m , mehsul_kateqoriya  mk where m.s_id="1" and mk.kat_u_id=:ds and m.u_id=mk.m_u_id and m.l_id=:lid  order by m.date desc');
                    }	
                    $contractquer->execute(array('lid'=>$lng1 , 'ds'=>s($_GET['cat'])));
                    $say=$contractquer->rowCount();
                ?>
				<section class="paginator">

					<ul>

					
                        <?php
                    $pCount = ceil($say/$limit);
                    $p = $page;
                    if ($arr[1]!='') {
                        $p = $arr[1];
                    } else $p = 1;
                    ?>
                    <li class="paginator-prev"><a <?php if($p>1){ echo 'href="'.$site_url.''.$lng.'/shop/'.$_GET['cat'].'/page='.intval($p-1).'/"'; } ?> ></a></li>
                    <?php    
                    for ($i = 1; $i <= $pCount; $i++) { 
                            
                         if ($i == $p) { ?>
                            <li class="active"><a style="cursor:pointer;" href="<?php echo $site_url.''.$lng.'/shop/'.$_GET['cat'].'/page='.$i.'/'; ?>"><?php echo $i; ?></a></li>
                        <?php } else if ($i <= 2) { ?>
                            <li><a  style="cursor:pointer;" href="<?php echo $site_url.''.$lng.'/shop/'.$_GET['cat'].'/page='.$i.'/'; ?>"><?php echo $i.''; ?></a></li>
                        <?php } else if ($pCount - 2 <= $i) { ?>
                            <li><a  style="cursor:pointer;" href="<?php echo $site_url.''.$lng.'/shop/'.$_GET['cat'].'/page='.$i.'/'; ?>"><?php echo $i.''; ?></a></li>
                        <?php } else if (($p - 2) <= $i AND ($p + 2) >= $i) { ?>
                            <li><a  style="cursor:pointer;" href="<?php echo $site_url.''.$lng.'/shop/'.$_GET['cat'].'/page='.$i.'/'; ?>"><?php echo $i.''; ?></a></li>
                        <?php } else if ($i < $p) { ?>
                            <li><a  style="cursor:pointer;" href="<?php echo $site_url.''.$lng.'/shop/'.$_GET['cat'].'/page='.round(($p - 2) / 2).'/';?>"><?php echo '...'; ?></a></li>
                            <?php $i = $p - 2;
                        } else if ($i > $p) { ?>
                            <li><a  style="cursor:pointer;" href="<?php echo $site_url.''.$lng.'/shop/'.$_GET['cat'].'/page='.round(($pCount  + $p) / 2).'/'; ?>"><?php echo '...'; ?></a>
                            </li>
                            <?php $i = $pCount - 2;
                        }  
            
                    }
                    ?>
                        
					<li class="paginator-next"><a <?php if($p!=$pCount){ echo 'href="'.$site_url.''.$lng.'/shop/'.$_GET['cat'].'/page='.intval($p+1).'/"'; } ?>></a></li>
						
					</ul>

				</section>
						
						<!--end paginator-->
						
				<?php } ?>		




						

					</div>







<!-- 					<section class="paginator">

						<ul>

						<li class="paginator-prev"><a href="#"></a></li>

							<li><a href="#">1</a></li>

							<li class="active"><a href="#">2</a></li>

							<li><a href="#">3</a></li>

							<li class="paginator-next"><a href="#"></a></li>

						</ul>

					</section> -->

				</div>

			</div>

		</div>

	</div>

</div>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>

<!-- <script src="<?PHP echo $site_url?>js/jquery.js"></script> -->

<script src="<?PHP echo $site_url ?>js/jquery-ui.js"></script>

<script>

$('.addtocart').on('click', function () 

{

	var cart = $('.shopping-cart');	//alert(cart);

	var imgtodrag = $(this).parents('.smcs').find(".otk").eq(0);

	console.log(imgtodrag);

	if (imgtodrag) 

	{

		var imgclone = imgtodrag.clone()

		.offset({

			top: imgtodrag.offset().top ,

			left: imgtodrag.offset().left

		})

		.css({

			'opacity': '0.5',

			'position': 'absolute',

			'height': '250px',

			'width': '250px',

			'top': imgtodrag.offset().top + 20,

			'left': imgtodrag.offset().left + 10,

			'z-index': '100'

		})

		.appendTo($('body'))

		.animate({

			'top': cart.offset().top + 15,

			'left': cart.offset().left + 30,

			'width': 50,

			'height': 50

		}, 1300, 'easeInOutExpo');  // setTimeout(function () {cart.effect("shake", { times: 2  }, 200); }, 1500);



		imgclone.animate({

			'width': 0,

			'height': 0

		}, function () 

		{

			$(this).detach()

		});

	}

});

</script>

<script type="text/javascript">

var ataarr = [];

function ekle(c)

{

	var inp_dat = document.getElementById(c);	

	var price = inp_dat.getAttribute('data-price');

	var image_url = inp_dat.getAttribute('data-img');

	var ship = inp_dat.getAttribute('data-ship');

	var name = inp_dat.getAttribute('data-name'); 

	var arr =  {"id":c , "price":price , "ship":ship ,"name":name , "image":image_url , "say":1  };



	if (localStorage.getItem("datalar1") === null)// datalar1 umumiyyetle yoxdursa hecne  filtirlemeden ilk vurulan butonu dataya elave edecek

	{ 

		ataarr.push(arr);

	} //<--- bunuun vasitesi ile

	else 

	{ 	

		ataarrx=localStorage.getItem("datalar1");

	 	ataarr=JSON.parse(ataarrx);	// yeni eger data varsa o zaman yoxlasin ki indi duymesi sixilanin datasi var ? //alert(ataarr.length); <-----bu arrayimizda ne qeder massiv oldugunu bize deyir

		var bil = 0; // storeg-de varsa bil axirda 1 e baeraber olacaq ve data elave olunmayacaq //alert(ataarr.length);

		for(var i=0 ; i<ataarr.length; i++) // bu for arrayin icindeki matrislerin sayi qeder donerek her matrisde duymesi sixilmis butonun idsi axatarilir ki bele bir id li data storegde varmi ?

		{

			if (ataarr[i].id==c)

			{

				var bil= 1; ataarr[i].say=ataarr[i].say+1; //eger varsa bil bire beraber olur ona gore ki , bilek ki bele bir data var

			}

		}

		if (bil==0)	

		{

			ataarr.push(arr);

		}		// fordan bu qeder donguye regmen bilin 1 e beraber olmamasi bu datanin olmadigi demekdir

		else

		{	

		}		//buna gorede datni localstorage elave edirik 

	} 



	var str_obj =JSON.stringify(ataarr);  // locala yollamaq ucun anlamsizlasdirib strinliyirik

	localStorage.setItem("datalar1",str_obj); // loacala yollayiriq



	if (localStorage.getItem("sebetsay1") === null)// sebet baxiriq ki hec elave olunubmu ? olunmayibsa sifira beraber edirik

	{

		localStorage.setItem("sebetsay1",0); // burada sifir edirik

	}

	var dats = localStorage.getItem("datalar1"); // datalar1i localdan cekirik

	var obj = JSON.parse(dats); //anlamlasdiririq

	var sebetsay1dat = parseInt(localStorage.getItem("sebetsay1")); // localda sebet sayini aliriq

	var sebet ;

	sebet = parseInt(localStorage.getItem("sebetsay1")); 

	localStorage.setItem("sebetsay1",sebet+1); // tiklananda 1 elave edirik 

	sebetsay1dat = parseInt(localStorage.getItem("sebetsay1"));

	update();

}



function update()

{

	//var gosteris =  document.getElementById("show_bar");

	if(localStorage.getItem("datalar1") !== null)

	{

		var yazi = localStorage.getItem("datalar1");

		var yaz1 = JSON.parse(yazi);

		//gosteris.innerHTML="";

		var tat ="";

		var total= 0;

		for (var b =0; b<yaz1.length; b++) 

		{

			if (isNaN(parseInt(yaz1[b].price))) 

			{

				yaz1[b].price = 0;

			}

			if (isNaN(parseInt(yaz1[b].ship))) 

			{

				yaz1[b].ship = 0;

			}



			total = total + (parseInt(yaz1[b].ship)+parseInt(yaz1[b].price))*parseInt(yaz1[b].say);

			var item_count = b +1;

			tat = tat + "<div id='basket_area'>"+"<span id='b_r' class='buy_row' style='float:left;' >"+"<span style='float:left;' id='numb'>"+item_count+"</span>"+"<span style='float:left;' class='pr_name'>"+yaz1[b].name+"</span>"+ "<div style='float:right;' onclick='dead("+JSON.stringify(yaz1[b].id)+")' class='item_close'><img src='http://localhost/lns/user/images/close-icon.png' ></div>"+ "<span id='pr_qty' style='float:right; margin-top:-7px; margin-bottom: 15px;'  > <div class='good_basket_btns clearfix'>        <div onclick='azal("+JSON.stringify(yaz1[b].id)+")' class='good_basket_min'></div>        <input type='text' class='good_basket_input form_text' value="+yaz1[b].say +">        <div class='good_basket_plus' onclick='art("+JSON.stringify(yaz1[b].id)+")'></div>    </div> </span>" + "<span style='float:right;' class='colored'>"+(parseInt(yaz1[b].price)+parseInt(yaz1[b].ship))+" <?php echo $_SESSION['valuvalyut']; ?>"+"</span>"+"</span></div>"  ;



			

		} //" shipping:"+yaz1[b].ship+ <img style='width: 12px; margin-bottom:5px;' src='<?=$site_url?>../user/images/azn.png'> "+"<img style='width: 15px; margin-bottom:5px;' src='<?=$site_url?>../user/images/azn.png'>



	 	tat = tat + "<hr  style=' z-index:99999; position:absolute; margin-bottom:-3px; margin-top:50px ; border:1px solid rgb(180, 180, 180); ' ><div id='xs_btn'  class='colored bskt_total ' style=' width:612px; border-top-style: solid; border-top-color: rgb(180,180,180);  border-width: 1px; padding-top:8px; padding-bottom:0px; ' id='bskt_total'> Total: "+total+" <?php echo $_SESSION['valuvalyut']; ?>"+"</div><section style='margin-top: 12px;' class='basket_check'><div class='basket_controls'><div class='basket_sum' style='float:none !important; display:block !important;'>			<div class='total_price_wrap'><div style='padding-bottom: 40px; margin-top: 0px; float:none !important;'  class='basket_sum_submit'><input style='margin-bottom: 20px; height:36px; line-height:0px; padding: 0 15px; font-weight: 549; font-size: 15px; ' type='submit' onclick='window.location.href=\"<?PHP echo $site_url.$lng2; ?>/basket/\"'    id='checkoutbtn' value='Proceed to checkout' ><input id='p_t_c' style='height:36px; line-height:0px; padding: 0 15px; font-weight: 549; font-size: 15px; float:left;     margin-bottom: 20px; ' type='submit' onclick='toggle()' value='Continue Shopping' ></div></div></div></div></section>" ;



		//$("#show_bar").html(tat);

	} 

	var sebetsay1dat = parseInt(localStorage.getItem("sebetsay1"));

	if(isNaN(sebetsay1dat))

	{

		document.getElementById('sebet').innerHTML="(" +0+")";

	}

	else 

	{

		document.getElementById('sebet').innerHTML="(" +sebetsay1dat+")";

	}

}



function toggle()

{

	var tiz =document.getElementById('show_bars');

	if (tiz.style.visibility==="hidden") 

	{

		tiz.style.visibility="visible"; 

		if(localStorage.getItem("datalar1") === null) 

		{

			var tat = "<hr style='margin-bottom:-3px; border:1px solid rgb(180, 180, 180); ' ><span class='colored bskt_total' id='bskt_total'>Total: "+0+"</span>" ;

			$("#show_bar").html(tat);

		}

	}

	else 

	{ 

		tiz.style.visibility="hidden"; 

	}

	update();

}



function art(did)

{

	var taze = JSON.parse(localStorage.getItem("datalar1"));



	for (var w = 0 ; w<taze.length  ; w++)

	{

		if (taze[w].id==did)

		{

			taze[w].say=parseInt(taze[w].say)+1;

		}



	}

	var tazestr = JSON.stringify(taze);

	localStorage.setItem("datalar1",tazestr);

	var sebet ;

	sebet = parseInt(localStorage.getItem("sebetsay1")); 

	localStorage.setItem("sebetsay1",sebet+1); // tiklananda 1 elave edirik 

	update();

}



function azal(did)

{

	var taze = JSON.parse(localStorage.getItem("datalar1"));	

	for (var w = 0 ; w<taze.length  ; w++) 

	{

		if (taze[w].id==did && taze[w].say>1 ) 

		{

			taze[w].say=parseInt(taze[w].say)-1;

			var sebet ;

			sebet = parseInt(localStorage.getItem("sebetsay1")); 

			localStorage.setItem("sebetsay1",sebet-1); // tiklananda 1 elave edirik 

		}

	}

	var tazestr = JSON.stringify(taze);

	localStorage.setItem("datalar1",tazestr);

	update();

}



function dead(did)

{

	var taze = JSON.parse(localStorage.getItem("datalar1"));	

	for (var w = 0 ; w<taze.length  ; w++) 

	{

		if (taze[w].id==did) 

		{

			if(confirm('Are you sure to remove  \" '+taze[w].name+' \"  from your basket?'))

			{				

				var silsebet= taze[w].say;				

				taze.splice(w,1);

				var sebet = parseInt(localStorage.getItem("sebetsay1")); 

				localStorage.setItem("sebetsay1",sebet-silsebet);

			}			

			else

			{

				alert("to be careful");

			}

		}

		else

		{			

		}

	}

	var tazestr = JSON.stringify(taze);

	localStorage.setItem("datalar1",tazestr);

	update();

}

update();

</script>	