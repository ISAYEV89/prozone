<?php 
    $userPr = $db->prepare('select * from user where id = ?');
    $userPr->execute([$_SESSION['id']]);
    $user = $userPr->fetch(PDO::FETCH_ASSOC);

?>
<div class="middle">

	<div class="container">
    <?php echo $_GET['page'] ?>
		<div class="page_title_wrapper">

			<div class="page_title"><?php echo $sign['product'][$lng] ?></div>

		</div>

		<div class="middle_content clearfix">

			<div class="left_sidebar">

				<div class="block_products_sidebar">

					<div class="block_content">

					<?php

					$lng1sor=$db->prepare('SELECT * FROM kateqoriyalar where s_id="0" and l_id=:lid  order by ordering asc  ');

              		$lng1sor->execute(array('lid'=>$lng1)); 

					$lng1count=$lng1sor->rowCount();

					$record=0;

              		while ($lng1cek=$lng1sor->fetch(PDO::FETCH_ASSOC)) 

                  	{ 

                  	$record++; 

					?>

						<div class="col col_<?php echo $record; ?>">

							<div class="image"><a href="<?php echo $site_url.$lng.'/shop/'.$lng1cek['kat_id'].'/'; ?>"><img src="<?php echo $site_url; ?>cms/images/<?php echo  $lng1cek['picture']; ?>" alt="<?php echo  $lng1cek['name']; ?>"></a></div>

							<div class="title"><div  class="field_content" ><a href="<?php echo $site_url.$lng.'/shop/'.$lng1cek['kat_id'].'/'; ?>"><?php echo  $lng1cek['name']; ?></a></div></div>

						</div>

					<?php

					}  

					?>

					</div>

				</div>

			</div>	

			<?php 

			$lng01sor=$db->prepare('SELECT * FROM mehsul where s_id="1" and l_id=:lid and u_id=:uid  ');

      		$lng01sor->execute(array('lid'=>$lng1 , 'uid'=>s($_GET['cname']))); 

			$lng01count=$lng01sor->rowCount();

			$lng01cek=$lng01sor->fetch(PDO::FETCH_ASSOC);

			$decods=0;

		 	?>

			<div class="page_content node_goods">

				<h1 class="node_title"><?php echo $lng01cek['name']; ?></h1>

				<div class="node_top clearfix">

					<div class="node_field article">

						<span class="label">Артикул:</span>

						<span class="field_content"><?php echo $lng01cek['track_code']; ?></span>

					</div>

					    <?php 
                        $query = $db->prepare('select * from stock where product_id = ?');
                        $query->execute([$lng01cek['u_id']]);
                        
                        if($query->rowCount() > 0){
                        ?><div class="node_field available">
						    <span class="field_content">Есть в наличии</span>
						  </div>  
						<?php }else{ ?>
						    <div class="node_field">
						        <span class="field_content"><i class="fa fa-times" style="color:red;"></i>  Is not available in stock</span>
						    </div>
						<?php } ?>

					

					<div class="node_field reviews_count">

						<span class="label">Отзывов:</span>

						<span class="field_content">254</span>

					</div>

				</div>

				<div class="node_main_wrap clearfix smcs" >

					<div class="image_wrapper">

						<div class="main_images">

							<?php

							$lng10sor=$db->prepare('SELECT * FROM mehsul_photo where m_u_id=:mud and l_id=:lid  order by ordering asc  ');

		              		$lng10sor->execute(array('lid'=>$lng1 ,'mud'=>s($_GET['cname']))); 

							$lng10count=$lng10sor->rowCount();

							$record=0;

		              		while ($lng10cek=$lng10sor->fetch(PDO::FETCH_ASSOC)) 

		                  	{ 

		              		?>

									<div class="image">

										<a href="#">

											<img class="otk" style="max-width:570px; max-height:375px;" src="<?php echo $site_url; ?>cms/images/<?php echo  $lng10cek['photo_url']; ?>" alt="<?php echo $lng10cek['alt'] ?>" >

										</a>

									</div>

							<?php

							}  

							?>

						</div>

						<div class="thumb_images">

						<?php

						$lng101sor=$db->prepare('SELECT * FROM mehsul_photo where m_u_id=:mud and l_id=:lid  order by ordering asc  ');

	              		$lng101sor->execute(array('lid'=>$lng1 ,'mud'=>s($_GET['cname']))); 

						$lng101count=$lng101sor->rowCount();

						$record=0;
                        ?>
                        	
                        <?php
	              		while ($lng101cek=$lng101sor->fetch(PDO::FETCH_ASSOC)) 

	                  	{ 

	              		?>
                            <div class="image">

							<div class="field_content">

									<img class="alt_img" src="<?php echo $site_url; ?>cms/images/<?php echo  $lng101cek['photo_url']; ?>" alt="<?php echo $lng101cek['alt'] ?>">

                            </div></div>
						<?php

						}  

						?>
						
						<?php 
						    $query = $db->prepare('SELECT * FROM product_gallery where product_id = ? order by ordering asc');
						    $query->execute([$_GET['cname']]);
                            
                        while ($image=$query->fetch(PDO::FETCH_ASSOC)) 

	                  	{						    
						?>
						<div class="image">

						   <div class="field_content">
 
						    <img class="alt_img" src="<?php echo $site_url; ?>cms/images/<?php echo  $image['image']; ?>" alt="<?php echo $image['image']; ?>">
                          
                          </div>
                        </div>						
						<?php } ?>
                        	
						
						</div>

					</div>

					<div class="price_wrapper">

						<div class="old_price">2 699</div>

						<div class="price">1 999 USD</div>

						<div class="good_basket clearfix">

							<div class="good_basket_btns clearfix">

								<div class="good_basket_min">Минус</div>

								<input type="text" class="good_basket_input form_text" id="tnt" disabled value="1">

								<div class="good_basket_plus">Плюс</div>

							</div>

							<div class="good_basket_add">

									<!-- <a href="#">Купить</a>	 -->		

							<?php

							if (!is_null($lng01cek['home']))

							{

							?>					

								<input style="border: none;" type="button" value='Купить'  data-text="Add To Cart"  class="addtocart add_to_basket" onclick="ekle(<?php echo $lng01cek['u_id'];  ?>)"  id="<?php echo $lng01cek['u_id'] ;  ?>" data-name="<?php echo $lng01cek['name'] ;  ?>"  data-ship="<?php echo $lng01cek['shipping_1'] ;  ?>" data-price="<?php echo $lng01cek['price_1'] ;  ?>" data-img="<?php echo $lng01cek['image_url'] ;  ?>"  >

							<?php 

							} 

							?>	

							</div>

						</div>

						<div class="one_click"><!-- Купить в один клик --></div>

						<div class="short_desc">

							К услугам покупателей часов LNS все функции веб-сайта, помогающие сделать верный выбор часов экстра-класса. В этом кроется единственная причина успеха компании LNS.

						</div>

						<div class="countdown_block">

							<div class="block_content">

								<div class="time_wrap">

									<div class="time_title">До конца акции осталось:</div>

									<div class="countdown_origin" data-time="00010">

										<div class="countdown_layout">

											<span class="tim">

												<span class="digit_group digit_group_1">

													<span class="digit count{d10}">{d10}</span>

													<span class="digit count{d1}">{d1}</span>		

												</span>

											    <span class="digit_Sep"></span>

												<span class="digit_group">

													<span class="digit count{h10}">{h10}</span>

													<span class="digit count{h1}">{h1}</span>

												</span>

											    <span class="digit_Sep"></span>

												<span class="digit_group">

													<span class="digit count{m10}">{m10}</span>

													<span class="digit count{m1}">{m1}</span>

												</span>

											    <span class="digit_Sep"></span>

												<span class="digit_group last">

													<span class="digit count{s10}">{s10}</span>

													<span class="digit count{s1}">{s1}</span>

												</span>

											</span>

											<span class="text">

											    <span class="day_text time_text">{dl}</span>

											    <span class="hour_text time_text">{hl}</span>

											    <span class="min_text time_text">{ml}</span>

											    <span class="sec_text time_text">{sl}</span>

											</span>

										</div>

									</div>

								</div>

							</div>

						</div>

					</div>

				</div>

				<div class="description_wrap clearfix node_item">

			<!--		<div class="label">

						<div class="text">Описание:</div>

						<div class="socials_buttons">

							<div class="social_label">Поделиться:</div>

							<div class="social-likes" data-counters="no">

								<div class="facebook" title="Поделиться ссылкой на Фейсбуке"><span>Facebook</span></div>

								<div class="vkontakte" title="Поделиться ссылкой во Вконтакте"><span>Вконтакте</span></div>

								<div class="plusone" title="Поделиться ссылкой в Гугл-плюсе"><span>Google</span>+</div>

								<div class="twitter" title="Поделиться ссылкой в Твиттере"><span>Twitter</span></div>

							</div>

							
							<div class="a2a_kit a2a_kit_size_32 a2a_default_style">

							<a class="a2a_dd" href="https://www.addtoany.com/share"></a>

							<a class="a2a_button_viber"></a>

							<a class="a2a_button_whatsapp"></a>

							<a class="a2a_button_telegram"></a>

							</div>

							<script async src="https://static.addtoany.com/menu/page.js"></script>

						
						</div>

					</div> -->

					<div class="field_content">

						<h2>LNS считаются недобросовестными и влекут за собой отмену права Клиента</h2>

					<!--	<div class="video"><iframe src="https://www.youtube.com/embed/hKLyOeZZx4c" allowfullscreen></iframe></div>  -->

						<div class="main_text">

							<p>Любые действия или деятельность, способные причинить или направленные на причинение ущерба репутации компании LNS, ее клиентам, или способные нанести ущерб коммерческим интересам компании LNS считаются недобросовестными и влекут за собой отмену права Клиента на совершение покупок. </p>



							<p>Любое информация противозаконного, мошеннического, угрожающего, оскорбительного, клеветнического, дискредитирующего, вульгарного, порнографического, вредного, назойливого, нечестного характера, либо посягающая на конфиденциальность данных другого клиента, или пропагандирующая ненависть, расовую, этническую и прочую неприязнь, или подлежит соглашению о конфиденциальности, или посягает на нашу интеллектуальную собственность и прочие права, в том числе и третьей стороны Любая внутренняя информация о той или иной компании</p>

						</div>

					</div>

				</div>
                <?PHP 
                    $product_details = $db->prepare('select * from product_details where product_id = ? and l_id = ?');
                    $product_details->execute([$_GET['cname'],$lng1]);
                    
                    if($product_details->rowCount() > 0){
                ?>
				<div class="chars_wrap clearfix node_item">

					<div class="label">Характеристики</div>

					<div class="field_content">
                        <?php while($detail = $product_details->fetch(PDO::FETCH_ASSOC)){ ?>                        
						<div class="char_content clearfix">

							<div class="char_1"><span><?php echo $detail['title'] ?></span></div>

							<div class="char_2"><?php echo $detail['description'] ?></div>

						</div>
                        <?php } ?>
					
					</div>

				</div>
				
				<?php } ?>

				<div class="reviews_wrap clearfix node_item">

					<div class="label">

						<div class="text">Отзывы</div>
                    <?php if($_SESSION['login']!='' and $_SESSION['x_ps']!='' ){ ?>    
						<div class="add_reviews">Добавить отзыв</div>
                    <?php } ?>
					</div>
                    <div class="comment_field" style="margin-top:100px;margin-bottom:35px; display:none;">
                        <form method="post"> 
                            <textarea class="form-control" name="comment_text" required></textarea>
                            <input id="comment_btn" name="comment_btn"  type="submit" value="Publish">
                        </form>
                    </div>
                    
                    
					<div class="field_content comment_field_content">
                        <?php
                            $comments=$db->prepare('select * from comment where product_id = ? order by date desc limit 4');
                            $comments->execute([$_GET['cname']]);
                            
                        if($comments->rowCount() > 0){$n=0;    
                        ?>
                        <?php while($comment = $comments->fetch(PDO::FETCH_ASSOC)){ $n++; ?>
						<?php
						
                            $comment_user = $db->prepare('select * from user where id = ?');
                            $comment_user->execute([$comment['user_id']]);
                            $cmmnt_user = $comment_user->fetch(PDO::FETCH_ASSOC);
                        if($n<=3){
                        ?>
						<div class="review">
                            
							<div class="name"><?php echo $cmmnt_user['ad'].' '.$cmmnt_user['soyad']  ?></div>

							<div class="date">
							    <?php $dekar=substr($comment['date'], 5,2);  echo substr($comment['date'], 8,2).' '.mounth($dekar,$lng1).' '.substr($comment['date'], 0,4).', '.substr($comment['date'], 10,6); ?>
							    </div>

							<div class="review_body">

								<?php echo $comment['text'] ?> 

							</div>
                        </div>
                        <?php } } 
                            if($comments->rowCount() > 3){
                        ?>
						
						<div class="more_reviews">Загрузить еще</div>
                        <?php
                            } 
                        } ?>
					</div>
                    
				</div>
                <script>
                    var limit = 6;
                    $('body').on('click','.more_reviews',function(){
                       var u_id = <?php echo $_GET['cname'] ?>;
                      
                      $.post("<?php echo $site_url ?>include/shop/comment.php", {suggest: u_id,limit: limit}, function(result){
                        //  alert(result);
                        $('.comment_field_content').html(result);
                        limit+=3;
                      }); 
                    });
                </script>
				<div class="block_goods similar_goods">

					<div class="block_title">Похожие товары</div>

					<div class="block_content">

					<?php

					$lng011sor=$db->prepare('SELECT * FROM mehsul where s_id="1" and l_id=:lid  order by rand() limit 3  ');

              		$lng011sor->execute(array('lid'=>$lng1)); 

					echo $lng011count=$lng011sor->rowCount();

					$disad=0;

              		while ($lng011cek=$lng011sor->fetch(PDO::FETCH_ASSOC)) 

                  	{  

              		$disad++;

					?>

						<div class="col col_<?php echo $disad; ?>">

							<div class="image">

								<div class="field_content"><img src="<?php echo $site_url.'cms/images/'.$lng011cek['image_url']; ?>" alt="<?php  echo $lng011cek['name']; ?>"></div>

							</div>

							<div class="title"><a href="<?php echo $site_url.$lng.'/shop/4/'.$lng011cek['u_id'].'/' ?>"><?php  echo $lng011cek['name']; ?>	</a></div>

							<div class="price_wrap">

								<div class="old_price" style="text-decoration: none;"><?php  if($lng011cek['home']==1){ echo $lng011cek['shipping_1'].' USD'; }  ?></div>

								<div class="price"><?php  if($lng011cek['home']==1){ echo $lng011cek['price_1'].' USD'; }  ?><span></span></div>

							</div>

							<div class="add_to_basket"><a href="<?php echo $site_url.$lng.'/shop/4/'.$lng011cek['u_id'].'/' ?>">Купить</a></div>

						</div>

<!-- 					<div class="col col_4">

						<div class="image">

							<div class="field_content"><img src="<?php echo $site_url; ?>images/good_2.png" alt="Товар"></div>

						</div>

						<div class="title"><a href="#">Masculine & Feminine Elegance LN7002/LN7004</a></div>

						<div class="price_wrap">

							<div class="old_price">2 699</div>

							<div class="price">1 999<span>руб</span></div>

						</div>

						<div class="add_to_basket"><a href="#">Купить</a></div>

					</div> -->

<!-- 					<div class="col col_4">

						<div class="image">

							<div class="field_content"><img src="<?php echo $site_url; ?>images/good_3.png" alt="Товар"></div>

						</div>

						<div class="title"><a href="#">Bottega Veneta Eau Legere EDT Eau De Toilette Spray 30ml/1oz Perfume</a></div>

						<div class="price_wrap">

							<div class="old_price">2 699</div>

							<div class="price">1 999<span>руб</span></div>

						</div>

						<div class="add_to_basket"><a href="#">Купить</a></div>

					</div> -->

<!-- 					<div class="col col_4">

						<div class="image">

							<div class="field_content"><img src="<?php echo $site_url; ?>images/good_4.png" alt="Товар"></div>

						</div>

						<div class="title"><a href="#">Masculine & Feminine Elegance LN7002/LN7004</a></div>

						<div class="price_wrap">

							<div class="old_price">2 699</div>

							<div class="price">1 999<span>руб</span></div>

						</div>

						<div class="add_to_basket"><a href="#">Купить</a></div>

					</div> -->

<!-- 					<div class="col col_4">

						<div class="image">

							<div class="field_content"><img src="<?php echo $site_url; ?>images/good_2.png" alt="Товар"></div>

						</div>

						<div class="title"><a href="#">Bottega Veneta Eau Legere EDT Eau De Toilette Spray 30ml/1oz Perfume</a></div>

						<div class="price_wrap">

							<div class="old_price">2 699</div>

							<div class="price">1 999<span>руб</span></div>

						</div>

						<div class="add_to_basket"><a href="#">Купить</a></div>

					</div> -->

					<?php

					}  

					?>

					</div>

				</div>

			</div>

		</div>

	</div>

</div>



<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>

<!-- <script src="<?PHP echo $site_url?>js/jquery.js"></script> -->

<script src="<?PHP echo $site_url ?>js/jquery-ui.js"></script>

<script>

$('.addtocart').on('click', function () 

{

	var cart = $('.shopping-cart');	//alert(cart);

	var imgtodrag = $(this).parents('.smcs').find(".otk").eq(0);

	console.log(imgtodrag);

	if (imgtodrag) 

	{

		var imgclone = imgtodrag.clone()

		.offset({

			top: imgtodrag.offset().top ,

			left: imgtodrag.offset().left

		})

		.css({

			'opacity': '0.5',

			'position': 'absolute',

			'height': '250px',

			'width': '250px',

			'top': imgtodrag.offset().top + 20,

			'left': imgtodrag.offset().left + 10,

			'z-index': '100'

		})

		.appendTo($('body'))

		.animate({

			'top': cart.offset().top + 15,

			'left': cart.offset().left + 30,

			'width': 50,

			'height': 50

		}, 1300, 'easeInOutExpo');  // setTimeout(function () {cart.effect("shake", { times: 2  }, 200); }, 1500);



		imgclone.animate({

			'width': 0,

			'height': 0

		}, function () 

		{

			$(this).detach()

		});

	}

});

</script>
<script>
    $('body').on('click','.add_reviews',function(){
       $('.comment_field').slideToggle(); 
    });
</script>
<script type="text/javascript">

var ataarr = [];

function ekle(c)

{

	var defe = document.getElementById('tnt').value;

	var inp_dat = document.getElementById(c);	

	var price = inp_dat.getAttribute('data-price');

	var image_url = inp_dat.getAttribute('data-img');

	var ship = inp_dat.getAttribute('data-ship');

	var name = inp_dat.getAttribute('data-name'); 

	var arr =  {"id":c , "price":price , "ship":ship ,"name":name , "image":image_url , "say":parseInt(defe)  };



	if (localStorage.getItem("datalar1") === null)// datalar1 umumiyyetle yoxdursa hecne  filtirlemeden ilk vurulan butonu dataya elave edecek

	{ 

		ataarr.push(arr);

	} //<--- bunuun vasitesi ile

	else 

	{ 	

		ataarrx=localStorage.getItem("datalar1");

	 	ataarr=JSON.parse(ataarrx);	// yeni eger data varsa o zaman yoxlasin ki indi duymesi sixilanin datasi var ? //alert(ataarr.length); <-----bu arrayimizda ne qeder massiv oldugunu bize deyir

		var bil = 0; // storeg-de varsa bil axirda 1 e baeraber olacaq ve data elave olunmayacaq //alert(ataarr.length);

		for(var i=0 ; i<ataarr.length; i++) // bu for arrayin icindeki matrislerin sayi qeder donerek her matrisde duymesi sixilmis butonun idsi axatarilir ki bele bir id li data storegde varmi ?

		{

			if (ataarr[i].id==c)

			{

				var bil= 1; ataarr[i].say=ataarr[i].say+parseInt(defe); //eger varsa bil bire beraber olur ona gore ki , bilek ki bele bir data var

			}

		}

		if (bil==0)	

		{

			ataarr.push(arr);

		}		// fordan bu qeder donguye regmen bilin 1 e beraber olmamasi bu datanin olmadigi demekdir

		else

		{	

		}		//buna gorede datni localstorage elave edirik 

	} 



	var str_obj =JSON.stringify(ataarr);  // locala yollamaq ucun anlamsizlasdirib strinliyirik

	localStorage.setItem("datalar1",str_obj); // loacala yollayiriq



	if (localStorage.getItem("sebetsay1") === null)// sebet baxiriq ki hec elave olunubmu ? olunmayibsa sifira beraber edirik

	{

		localStorage.setItem("sebetsay1",0); // burada sifir edirik

	}

	var dats = localStorage.getItem("datalar1"); // datalar1i localdan cekirik

	var obj = JSON.parse(dats); //anlamlasdiririq

	var sebetsay1dat = parseInt(localStorage.getItem("sebetsay1")); // localda sebet sayini aliriq

	var sebet ;

	sebet = parseInt(localStorage.getItem("sebetsay1")); 

	localStorage.setItem("sebetsay1",sebet+parseInt(defe)); // tiklananda 1 elave edirik 

	sebetsay1dat = parseInt(localStorage.getItem("sebetsay1"));

	update();

}



function update()

{

	//var gosteris =  document.getElementById("show_bar");

	if(localStorage.getItem("datalar1") !== null)

	{

		var yazi = localStorage.getItem("datalar1");

		var yaz1 = JSON.parse(yazi);

		//gosteris.innerHTML="";

		var tat ="";

		var total= 0;

		for (var b =0; b<yaz1.length; b++) 

		{

			if (isNaN(parseInt(yaz1[b].price))) 

			{

				yaz1[b].price = 0;

			}

			if (isNaN(parseInt(yaz1[b].ship))) 

			{

				yaz1[b].ship = 0;

			}



			total = total + (parseInt(yaz1[b].ship)+parseInt(yaz1[b].price))*parseInt(yaz1[b].say);

			var item_count = b +1;

			tat = tat + "<div id='basket_area'>"+"<span id='b_r' class='buy_row' style='float:left;' >"+"<span style='float:left;' id='numb'>"+item_count+"</span>"+"<span style='float:left;' class='pr_name'>"+yaz1[b].name+"</span>"+ "<div style='float:right;' onclick='dead("+JSON.stringify(yaz1[b].id)+")' class='item_close'><img src='http://localhost/lns/user/images/close-icon.png' ></div>"+ "<span id='pr_qty' style='float:right; margin-top:-7px; margin-bottom: 15px;'  > <div class='good_basket_btns clearfix'>        <div onclick='azal("+JSON.stringify(yaz1[b].id)+")' class='good_basket_min'></div>        <input type='text' class='good_basket_input form_text' value="+yaz1[b].say +">        <div class='good_basket_plus' onclick='art("+JSON.stringify(yaz1[b].id)+")'></div>    </div> </span>" + "<span style='float:right;' class='colored'>"+(parseInt(yaz1[b].price)+parseInt(yaz1[b].ship))+" <?php echo $_SESSION['valuvalyut']; ?>"+"</span>"+"</span></div>"  ;



			

		} //" shipping:"+yaz1[b].ship+ <img style='width: 12px; margin-bottom:5px;' src='<?=$site_url?>../user/images/azn.png'> "+"<img style='width: 15px; margin-bottom:5px;' src='<?=$site_url?>../user/images/azn.png'>



	 	tat = tat + "<hr  style=' z-index:99999; position:absolute; margin-bottom:-3px; margin-top:50px ; border:1px solid rgb(180, 180, 180); ' ><div id='xs_btn'  class='colored bskt_total ' style=' width:612px; border-top-style: solid; border-top-color: rgb(180,180,180);  border-width: 1px; padding-top:8px; padding-bottom:0px; ' id='bskt_total'> Total: "+total+" <?php echo $_SESSION['valuvalyut']; ?>"+"</div><section style='margin-top: 12px;' class='basket_check'><div class='basket_controls'><div class='basket_sum' style='float:none !important; display:block !important;'>			<div class='total_price_wrap'><div style='padding-bottom: 40px; margin-top: 0px; float:none !important;'  class='basket_sum_submit'><input style='margin-bottom: 20px; height:36px; line-height:0px; padding: 0 15px; font-weight: 549; font-size: 15px; ' type='submit' onclick='window.location.href=\"<?PHP echo $site_url.$lng2; ?>/basket/\"'    id='checkoutbtn' value='Proceed to checkout' ><input id='p_t_c' style='height:36px; line-height:0px; padding: 0 15px; font-weight: 549; font-size: 15px; float:left;     margin-bottom: 20px; ' type='submit' onclick='toggle()' value='Continue Shopping' ></div></div></div></div></section>" ;



		//$("#show_bar").html(tat);

	} 

	var sebetsay1dat = parseInt(localStorage.getItem("sebetsay1"));

	if(isNaN(sebetsay1dat))

	{

		document.getElementById('sebet').innerHTML="(" +0+")";

	}

	else 

	{

		document.getElementById('sebet').innerHTML="(" +sebetsay1dat+")";

	}

}



function toggle()

{

	var tiz =document.getElementById('show_bars');

	if (tiz.style.visibility==="hidden") 

	{

		tiz.style.visibility="visible"; 

		if(localStorage.getItem("datalar1") === null) 

		{

			var tat = "<hr style='margin-bottom:-3px; border:1px solid rgb(180, 180, 180); ' ><span class='colored bskt_total' id='bskt_total'>Total: "+0+"</span>" ;

			$("#show_bar").html(tat);

		}

	}

	else 

	{ 

		tiz.style.visibility="hidden"; 

	}

	update();

}



function art(did)

{

	var taze = JSON.parse(localStorage.getItem("datalar1"));



	for (var w = 0 ; w<taze.length  ; w++)

	{

		if (taze[w].id==did)

		{

			taze[w].say=parseInt(taze[w].say)+1;

		}



	}

	var tazestr = JSON.stringify(taze);

	localStorage.setItem("datalar1",tazestr);

	var sebet ;

	sebet = parseInt(localStorage.getItem("sebetsay1")); 

	localStorage.setItem("sebetsay1",sebet+1); // tiklananda 1 elave edirik 

	update();

}



function azal(did)

{

	var taze = JSON.parse(localStorage.getItem("datalar1"));	

	for (var w = 0 ; w<taze.length  ; w++) 

	{

		if (taze[w].id==did && taze[w].say>1 ) 

		{

			taze[w].say=parseInt(taze[w].say)-1;

			var sebet ;

			sebet = parseInt(localStorage.getItem("sebetsay1")); 

			localStorage.setItem("sebetsay1",sebet-1); // tiklananda 1 elave edirik 

		}

	}

	var tazestr = JSON.stringify(taze);

	localStorage.setItem("datalar1",tazestr);

	update();

}



function dead(did)

{

	var taze = JSON.parse(localStorage.getItem("datalar1"));	

	for (var w = 0 ; w<taze.length  ; w++) 

	{

		if (taze[w].id==did) 

		{

			if(confirm('Are you sure to remove  \" '+taze[w].name+' \"  from your basket?'))

			{				

				var silsebet= taze[w].say;				

				taze.splice(w,1);

				var sebet = parseInt(localStorage.getItem("sebetsay1")); 

				localStorage.setItem("sebetsay1",sebet-silsebet);

			}			

			else

			{

				alert("to be careful");

			}

		}

		else

		{			

		}

	}

	var tazestr = JSON.stringify(taze);

	localStorage.setItem("datalar1",tazestr);

	update();

}

update();


// change image

$('body').on('click','.alt_img',function(){
   $('.otk').attr('src',$(this).attr('src')); 
});
</script>
<style>
    #comment_btn{
        border: 1px solid #43B9DA;
        color: #43B9DA;
        background-color:#fff;
        padding: 10px;
        box-shadow: 0 2px 2px rgba(15, 55, 66, 0.1);
    }
    #comment_btn:hover{
        background-color: #43B9DA;
        color:#fff;
    }
</style>
<?php

if(isset($_POST['comment_btn'])){
    
    
    $add_comment = $db->prepare('insert into comment set user_id = ?, product_id = ?, text = ?');
    $add_comment->execute([$user['id'],$_GET['cname'],$_POST['comment_text']]);
    
    header('Location: .');
}

?>
